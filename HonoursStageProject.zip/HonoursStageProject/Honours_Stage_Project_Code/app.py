from __future__ import annotations

import os
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)

app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-change-me")

DB_USER = os.environ.get("DB_USER", "admin")
DB_PASS = os.environ.get("DB_PASS", "A-Strong-Password")
DB_HOST = os.environ.get("DB_HOST", "127.0.0.1")
DB_PORT = os.environ.get("DB_PORT", "3306")
DB_NAME = os.environ.get("DB_NAME", "honoursstageproject")

app.config["SQLALCHEMY_DATABASE_URI"] = (
    f"mysql+pymysql://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}?charset=utf8mb4"
)
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)


class Role(db.Model):
    __tablename__ = "roles"

    role_id = db.Column(db.SmallInteger, primary_key=True, autoincrement=True)
    role_name = db.Column(db.String(32), unique=True, nullable=False)


class User(db.Model):
    __tablename__ = "users"

    user_id = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role_id = db.Column(db.SmallInteger, db.ForeignKey("roles.role_id"), nullable=False)
    is_active = db.Column(db.Boolean, nullable=False, default=True)

    role = db.relationship("Role")


class Form(db.Model):
    __tablename__ = "form"

    form_id = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    form_key = db.Column(db.String(64), unique=True, nullable=False)
    title = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    created_by = db.Column(db.BigInteger, db.ForeignKey("users.user_id"), nullable=False)


class FormVersion(db.Model):
    __tablename__ = "form_versions"

    form_version_id = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    form_id = db.Column(db.BigInteger, db.ForeignKey("form.form_id"), nullable=False)
    version_number = db.Column(db.Integer, nullable=False)
    created_by = db.Column(db.BigInteger, db.ForeignKey("users.user_id"), nullable=False)
    notes = db.Column(db.String(255), nullable=True)


class QuestionVersion(db.Model):
    __tablename__ = "question_versions"

    question_version_id = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    question_id = db.Column(db.BigInteger, db.ForeignKey("questions.question_id"), nullable=False)
    version_number = db.Column(db.Integer, nullable=False)
    prompt_text = db.Column(db.Text, nullable=False)
    response_type = db.Column(db.String(32), nullable=False)
    is_required = db.Column(db.Boolean, nullable=False, default=False)
    help_text = db.Column(db.Text, nullable=True)
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    created_by = db.Column(db.BigInteger, db.ForeignKey("users.user_id"), nullable=False)


class FormVersionQuestion(db.Model):
    __tablename__ = "form_version_questions"

    form_version_question_id = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    form_version_id = db.Column(db.BigInteger, db.ForeignKey("form_versions.form_version_id"), nullable=False)
    question_version_id = db.Column(db.BigInteger, db.ForeignKey("question_versions.question_version_id"), nullable=False)
    sort_order = db.Column(db.Integer, nullable=False, default=0)


def login_required(view_func):
    @wraps(view_func)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            return redirect(url_for("index"))
        return view_func(*args, **kwargs)
    return wrapper


def seed_roles_if_missing():
    for role_name in ("admin", "standard"):
        if not Role.query.filter_by(role_name=role_name).first():
            db.session.add(Role(role_name=role_name))
    db.session.commit()


@app.before_request
def _ensure_db_ready():
    if not app.config.get("_SEEDED_ROLES"):
        db.session.execute(db.text("SELECT 1"))
        seed_roles_if_missing()
        app.config["_SEEDED_ROLES"] = True


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""

        user = User.query.filter_by(username=username).first()
        if not user or not user.is_active or not check_password_hash(user.password_hash, password):
            flash("Invalid username or password.", "error")
            return render_template("index.html"), 401

        session["user_id"] = int(user.user_id)
        session["username"] = user.username
        session["role_name"] = user.role.role_name if user.role else None
        return redirect(url_for("dashboard"))

    return render_template("index.html")


@app.route("/signup", methods=["GET", "POST"])
def signup():
    roles = Role.query.all()

    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""
        confirm = request.form.get("confirm_password") or ""
        role_id = request.form.get("role_id")

        if not username or len(username) > 64:
            flash("Invalid username.", "error")
            return render_template("signup.html", roles=roles), 400

        if password != confirm or len(password) < 8:
            flash("Invalid password.", "error")
            return render_template("signup.html", roles=roles), 400

        if not role_id:
            flash("Role selection required.", "error")
            return render_template("signup.html", roles=roles), 400

        if User.query.filter_by(username=username).first():
            flash("Username already exists.", "error")
            return render_template("signup.html", roles=roles), 409

        user = User(
            username=username,
            password_hash=generate_password_hash(password),
            role_id=int(role_id),
            is_active=True,
        )
        db.session.add(user)
        db.session.commit()

        flash("Account created.", "success")
        return redirect(url_for("index"))

    return render_template("signup.html", roles=roles)


@app.route("/reset-password", methods=["GET", "POST"])
def reset_password():
    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        new_password = request.form.get("new_password") or ""
        confirm = request.form.get("confirm_new_password") or ""

        if new_password != confirm or len(new_password) < 8:
            flash("Invalid password.", "error")
            return render_template("reset_password.html"), 400

        user = User.query.filter_by(username=username).first()
        if not user:
            flash("User not found.", "error")
            return render_template("reset_password.html"), 404

        user.password_hash = generate_password_hash(new_password)
        db.session.commit()

        flash("Password updated.", "success")
        return redirect(url_for("index"))

    return render_template("reset_password.html")


@app.route("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))


@app.route("/form")
@login_required
def form():
    form = db.session.query(Form).filter(Form.is_active == 1).first()

    if not form:
        return render_template("form.html", form=None)

    latest_version = (
        db.session.query(FormVersion)
        .filter(FormVersion.form_id == form.form_id)
        .order_by(FormVersion.version_number.desc())
        .first()
    )

    if not latest_version:
        return render_template("form.html", form=form, form_version=None, questions=[])

    questions = (
        db.session.query(QuestionVersion)
        .join(
            FormVersionQuestion,
            FormVersionQuestion.question_version_id == QuestionVersion.question_version_id,
        )
        .filter(FormVersionQuestion.form_version_id == latest_version.form_version_id)
        .order_by(FormVersionQuestion.sort_order)
        .all()
    )

    return render_template(
        "form.html",
        form=form,
        form_version=latest_version,
        questions=questions,
    )


@app.route("/stats")
@login_required
def stats():
    return render_template("stats.html")


if __name__ == "__main__":
    app.run(debug=True)
