USE honoursstageproject;

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS submission_answers;
DROP TABLE IF EXISTS form_submissions;
DROP TABLE IF EXISTS form_version_questions;
DROP TABLE IF EXISTS question_version_options;
DROP TABLE IF EXISTS question_versions;
DROP TABLE IF EXISTS questions;
DROP TABLE IF EXISTS form_versions;
DROP TABLE IF EXISTS forms;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS roles;

SET FOREIGN_KEY_CHECKS = 1;